// content_script.js
const originalFetch = window.fetch;

window.fetch = async (resource, init) => {
  const url = typeof resource === 'string' ? resource : resource.url;
  if (url.includes('.twitch.tv/ads/') || url.match(/adseg\//)) {
    return new Response('', { status: 204 });
  }
  return originalFetch(resource, init);
};

function skipVideoAds() {
  const v = document.querySelector('video');
  if (v && !v._adSkipped) {
    v.currentTime = v.duration;
    v._adSkipped = true;
  }
}

const obs = new MutationObserver(() => setTimeout(skipVideoAds, 500));
obs.observe(document, { childList: true, subtree: true });
setInterval(skipVideoAds, 2000);
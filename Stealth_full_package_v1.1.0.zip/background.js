// background.js
chrome.runtime.onInstalled.addListener(updateBlockRules);
chrome.alarms.create('updateRules', { periodInMinutes: 360 });
chrome.alarms.onAlarm.addListener(a => a.name === 'updateRules' && updateBlockRules());

async function updateBlockRules() {
  const { updatesEnabled } = await chrome.storage.sync.get({ updatesEnabled: true });
  if (!updatesEnabled) return;
  try {
    const res = await fetch('https://raw.githubusercontent.com/eclipsetm89/Stealth/main/rules.json');
    const rules = await res.json();
    const removeIds = rules.map(r => r.id);
    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: rules, removeRuleIds: removeIds });
  } catch (e) {
    console.error('Rule update failed', e);
  }
}